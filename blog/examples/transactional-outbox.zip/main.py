#!/usr/bin/env python3
import json
import sqlite3
import tempfile
from pathlib import Path


def return_loan(db):
    # One local transaction makes the return and publication intent durable.
    with db:
        db.execute("UPDATE loans SET status='returned' WHERE id=1")
        db.execute("INSERT INTO outbox(id, topic, body) VALUES (101, 'loan.returned', ?)", (json.dumps({"id": 1}),))


def relay_once(db, broker, fail_after_publish=False):
    # Pending remains queryable until a separate broker write has succeeded.
    row = db.execute("SELECT id, topic, body FROM outbox WHERE published=0 ORDER BY id LIMIT 1").fetchone()
    if not row:
        return False
    # Publishing and marking complete cannot share the SQLite transaction.
    broker.append(row)
    print("relay published event", row[0])
    if fail_after_publish:
        # The next relay call will publish this stable event ID again.
        raise RuntimeError("simulated failure after publish, before marking complete")
    with db:
        db.execute("UPDATE outbox SET published=1 WHERE id=?", (row[0],))
    return True


def consume(broker):
    # This in-memory set demonstrates identity, not durable consumer deduplication.
    seen = set()
    effects = []
    for event_id, topic, body in broker:
        if event_id in seen:
            print("consumer ignored duplicate", event_id)
            continue
        # A real consumer records this ID atomically with its own database effect.
        seen.add(event_id)
        effects.append((topic, json.loads(body)["id"]))
    return effects


def main():
    with tempfile.TemporaryDirectory() as directory:
        path = Path(directory) / "demo.db"
        db = sqlite3.connect(path)
        db.executescript("""
            CREATE TABLE loans(id INTEGER PRIMARY KEY, status TEXT NOT NULL);
            CREATE TABLE outbox(id INTEGER PRIMARY KEY, topic TEXT NOT NULL, body TEXT NOT NULL, published INTEGER NOT NULL DEFAULT 0);
            INSERT INTO loans VALUES(1, 'borrowed');
        """)
        return_loan(db)
        db.close()
        print("producer connection closed after database commit, before relay")

        db = sqlite3.connect(path)
        broker = []
        try:
            relay_once(db, broker, fail_after_publish=True)
        except RuntimeError as error:
            print(error)
        relay_once(db, broker)

        effects = consume(broker)
        assert len(broker) == 2
        assert effects == [("loan.returned", 1)]
        assert db.execute("SELECT status FROM loans WHERE id=1").fetchone()[0] == "returned"
        assert db.execute("SELECT published FROM outbox WHERE id=101").fetchone()[0] == 1
        print("broker deliveries=2; consumer effects=1; pending outbox rows=0")


if __name__ == "__main__":
    main()
